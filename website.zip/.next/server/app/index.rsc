1:"$Sreact.fragment"
2:I[9766,[],""]
3:I[8924,[],""]
4:I[6342,["842","static/chunks/842-64f4c5c5dc354dc9.js","974","static/chunks/app/page-13cdb228707a0010.js"],"default"]
5:I[2500,["842","static/chunks/842-64f4c5c5dc354dc9.js","974","static/chunks/app/page-13cdb228707a0010.js"],"default"]
6:I[793,["842","static/chunks/842-64f4c5c5dc354dc9.js","974","static/chunks/app/page-13cdb228707a0010.js"],"default"]
7:I[9761,["842","static/chunks/842-64f4c5c5dc354dc9.js","974","static/chunks/app/page-13cdb228707a0010.js"],"default"]
8:I[4528,["842","static/chunks/842-64f4c5c5dc354dc9.js","974","static/chunks/app/page-13cdb228707a0010.js"],"default"]
9:I[4797,["842","static/chunks/842-64f4c5c5dc354dc9.js","974","static/chunks/app/page-13cdb228707a0010.js"],"default"]
a:I[5397,["842","static/chunks/842-64f4c5c5dc354dc9.js","974","static/chunks/app/page-13cdb228707a0010.js"],"default"]
b:I[8452,["842","static/chunks/842-64f4c5c5dc354dc9.js","974","static/chunks/app/page-13cdb228707a0010.js"],"default"]
c:I[4431,[],"OutletBoundary"]
e:I[5278,[],"AsyncMetadataOutlet"]
10:I[4431,[],"ViewportBoundary"]
12:I[4431,[],"MetadataBoundary"]
13:"$Sreact.suspense"
15:I[7150,[],""]
:HL["/_next/static/css/d03fd1a01ede4364.css","style"]
0:{"P":null,"b":"ixPEs6GFh8wGZzzZq1Zar","p":"","c":["",""],"i":false,"f":[[["",{"children":["__PAGE__",{}]},"$undefined","$undefined",true],["",["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/d03fd1a01ede4364.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","html",null,{"lang":"en","children":["$","body",null,{"className":"__variable_246ccd __variable_c29908 __variable_dd5b2f __variable_f367f3 __variable_1f5468 antialiased","suppressHydrationWarning":true,"children":["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L3",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}]]}],{"children":["__PAGE__",["$","$1","c",{"children":[["$","$L4",null,{"children":["$","div",null,{"className":"crud-site","children":[["$","$L5",null,{}],["$","$L6",null,{}],["$","main",null,{"children":[["$","$L7",null,{}],["$","$L8",null,{}],["$","$L9",null,{}],["$","$La",null,{}]]}],["$","$Lb",null,{}]]}]}],null,["$","$Lc",null,{"children":["$Ld",["$","$Le",null,{"promise":"$@f"}]]}]]}],{},null,false]},null,false],["$","$1","h",{"children":[null,[["$","$L10",null,{"children":"$L11"}],null],["$","$L12",null,{"children":["$","div",null,{"hidden":true,"children":["$","$13",null,{"fallback":null,"children":"$L14"}]}]}]]}],false]],"m":"$undefined","G":["$15",[]],"s":false,"S":true}
11:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
d:null
16:I[622,[],"IconMark"]
f:{"metadata":[["$","title","0",{"children":"CRUD — The Design Studio | Ideas to Iconic Brands"}],["$","meta","1",{"name":"description","content":"CRUD (Create Refine Unified Designs) is a design agency crafting powerful brands through innovative design, seamless web development, and strategic digital solutions."}],["$","link","2",{"rel":"icon","href":"/favicon.ico","type":"image/x-icon","sizes":"16x16"}],["$","$L16","3",{}]],"error":null,"digest":"$undefined"}
14:"$f:metadata"
