'use client';

import { useState } from 'react';
import Link from 'next/link';
import { AnimatePresence, motion, useMotionValueEvent, useScroll } from 'framer-motion';
import { healthPackages, hospital } from '@/lib/medinova-data';

const ease = [0.22, 1, 0.36, 1] as const;

/* ============================================================
   Demo nav — the 9 "pages" map to sections of this concept
   ============================================================ */
const navLinks = [
  { label: 'Home', target: '#home' },
  { label: 'About', target: '#about' },
  { label: 'Doctors', target: '#doctors' },
  { label: 'Specialities', target: '#specialities' },
  { label: 'Book', target: '#book' },
  { label: 'Packages', target: '#packages' },
  { label: 'Emergency', target: '#emergency' },
  { label: 'Stories', target: '#stories' },
  { label: 'Contact', target: '#contact' },
];

export function MediNav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const { scrollY } = useScroll();

  useMotionValueEvent(scrollY, 'change', (v) => setScrolled(v > 30));

  return (
    <>
      {/* concept banner */}
      <div className="fixed inset-x-0 top-0 z-[110] flex items-center justify-center gap-3 bg-gradient-to-r from-cyan-500/15 via-violet-500/15 to-cyan-500/15 px-4 py-1.5 backdrop-blur-md">
        <p className="text-center text-[11px] font-semibold uppercase tracking-[0.18em] text-cyan-200">
          Concept demo by CRUD Studio
        </p>
        <Link
          href="/"
          className="rounded-full border border-cyan-300/40 px-3 py-0.5 text-[10px] font-bold uppercase tracking-wider text-cyan-100 transition-colors hover:bg-cyan-300 hover:text-slate-950"
        >
          ← Back to CRUD
        </Link>
      </div>

      <header
        className={`fixed inset-x-0 top-7 z-[100] transition-all duration-500 ${
          scrolled ? 'bg-slate-950/75 shadow-lg shadow-slate-950/40 backdrop-blur-xl' : 'bg-transparent'
        }`}
      >
        <div className="flex items-center justify-between px-5 py-3.5 md:px-10">
          <a href="#home" className="flex items-center gap-2.5" aria-label="MediNova home">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-400 to-sky-600 font-display text-lg font-bold text-slate-950">
              +
            </span>
            <span className="font-display text-lg font-bold tracking-tight text-white">
              Medi<span className="text-cyan-300">Nova</span>
            </span>
          </a>

          <nav className="hidden items-center gap-6 xl:flex" aria-label="MediNova primary">
            {navLinks.map((l) => (
              <a
                key={l.label}
                href={l.target}
                className={`font-display text-[13px] font-semibold uppercase tracking-wider transition-colors hover:text-cyan-300 ${
                  l.label === 'Emergency' ? 'text-rose-400 hover:text-rose-300' : 'text-slate-400'
                }`}
              >
                {l.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            <a
              href="#book"
              className="hidden rounded-full bg-cyan-400 px-5 py-2.5 font-display text-xs font-bold uppercase tracking-wider text-slate-950 transition-transform hover:scale-105 md:block"
            >
              Book now
            </a>
            <button
              onClick={() => setOpen((v) => !v)}
              aria-expanded={open}
              aria-label={open ? 'Close menu' : 'Open menu'}
              className="relative flex h-10 w-10 items-center justify-center rounded-full border border-white/15 xl:hidden"
            >
              <span className={`absolute h-px w-4 bg-white transition-all ${open ? 'rotate-45' : '-translate-y-1'}`} />
              <span className={`absolute h-px w-4 bg-white transition-all ${open ? '-rotate-45' : 'translate-y-1'}`} />
            </button>
          </div>
        </div>
      </header>

      <AnimatePresence>
        {open && (
          <motion.nav
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-x-4 top-24 z-[105] grid grid-cols-2 gap-2 rounded-3xl border border-white/10 bg-slate-950/95 p-4 backdrop-blur-xl xl:hidden"
            aria-label="MediNova mobile"
          >
            {navLinks.map((l) => (
              <a
                key={l.label}
                href={l.target}
                onClick={() => setOpen(false)}
                className={`rounded-xl px-4 py-3 font-display text-sm font-semibold ${
                  l.label === 'Emergency' ? 'bg-rose-500/10 text-rose-300' : 'bg-white/[0.04] text-slate-200'
                }`}
              >
                {l.label}
              </a>
            ))}
          </motion.nav>
        )}
      </AnimatePresence>
    </>
  );
}

/* ============================================================
   Health packages
   ============================================================ */
export function Packages() {
  return (
    <section id="packages" className="relative px-5 py-24 md:px-10">
      <div className="mb-12 text-center">
        <p className="mb-3 inline-flex items-center gap-3 text-xs font-semibold uppercase tracking-[0.3em] text-cyan-300">
          <span className="h-px w-8 bg-cyan-400" /> Health packages <span className="h-px w-8 bg-cyan-400" />
        </p>
        <h2 className="font-display text-4xl font-bold tracking-tight text-white md:text-6xl">
          Prevention, priced clearly.
        </h2>
      </div>

      <div className="mx-auto grid max-w-5xl gap-5 md:grid-cols-3">
        {healthPackages.map((p, i) => (
          <motion.div
            key={p.id}
            initial={{ opacity: 0, y: 36 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.65, delay: i * 0.1, ease }}
            className={`relative flex flex-col rounded-3xl border p-7 ${
              p.popular
                ? 'border-cyan-400/50 bg-gradient-to-b from-cyan-950/50 to-slate-900 shadow-2xl shadow-cyan-500/10'
                : 'border-white/10 bg-white/[0.03]'
            }`}
          >
            {p.popular && (
              <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-cyan-400 px-4 py-1 text-[11px] font-bold uppercase tracking-wider text-slate-950">
                Most chosen
              </span>
            )}
            <h3 className="font-display text-xl font-bold text-white">{p.name}</h3>
            <p className="mt-1 text-xs uppercase tracking-wider text-slate-500">{p.tests} tests included</p>
            <p className="mt-5 font-display text-4xl font-bold text-white">
              {p.price}
              <span className="text-sm font-normal text-slate-500"> / person</span>
            </p>
            <ul className="mt-6 flex-1 space-y-2.5">
              {p.includes.map((item) => (
                <li key={item} className="flex items-start gap-2.5 text-sm text-slate-300">
                  <span className="mt-0.5 text-cyan-300">✓</span> {item}
                </li>
              ))}
            </ul>
            <a
              href="#book"
              className={`mt-8 rounded-full py-3.5 text-center font-display text-sm font-bold uppercase tracking-wider transition-transform hover:scale-[1.02] ${
                p.popular ? 'bg-cyan-400 text-slate-950' : 'border border-white/15 text-white hover:border-cyan-400/50'
              }`}
            >
              Book this package
            </a>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

/* ============================================================
   Emergency band
   ============================================================ */
export function EmergencyBand() {
  return (
    <section id="emergency" className="relative px-5 py-12 md:px-10">
      <motion.div
        initial={{ opacity: 0, scale: 0.98 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.7, ease }}
        className="relative mx-auto max-w-6xl overflow-hidden rounded-[2rem] border border-rose-500/30 bg-gradient-to-r from-rose-950/80 via-slate-900 to-slate-900 p-8 md:p-12"
      >
        <motion.div
          aria-hidden
          className="absolute -left-20 top-1/2 h-64 w-64 -translate-y-1/2 rounded-full bg-rose-500/20 blur-3xl"
          animate={{ opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 2.2, repeat: Infinity }}
        />
        <div className="relative flex flex-col items-start gap-6 md:flex-row md:items-center md:justify-between">
          <div>
            <p className="flex items-center gap-2 text-xs font-bold uppercase tracking-[0.25em] text-rose-300">
              <span className="relative flex h-2.5 w-2.5">
                <span className="absolute h-full w-full animate-ping rounded-full bg-rose-400 opacity-75" />
                <span className="relative h-2.5 w-2.5 rounded-full bg-rose-400" />
              </span>
              Emergency &amp; trauma — 24×7
            </p>
            <h2 className="mt-3 font-display text-3xl font-bold text-white md:text-5xl">
              Golden hour ready.
              <span className="text-rose-300"> Always.</span>
            </h2>
            <p className="mt-3 max-w-lg text-sm leading-relaxed text-slate-400">
              Dedicated trauma bays, stroke and cardiac fast-tracks, and an ambulance network with live GPS dispatch — door-to-needle in under 20 minutes.
            </p>
          </div>
          <a
            href={`tel:${hospital.emergency}`}
            className="group flex items-center gap-4 rounded-2xl border border-rose-400/40 bg-rose-500/10 px-7 py-5 transition-colors hover:bg-rose-500/20"
          >
            <span className="font-display text-5xl font-bold text-rose-300">{hospital.emergency}</span>
            <span className="text-left text-xs uppercase leading-relaxed tracking-wider text-slate-300">
              Tap to call
              <br />
              ambulance
            </span>
          </a>
        </div>
      </motion.div>
    </section>
  );
}

/* ============================================================
   Footer / contact
   ============================================================ */
export function MediFooter() {
  return (
    <footer id="contact" className="relative border-t border-white/10 px-5 pb-10 pt-20 md:px-10">
      <div className="mx-auto grid max-w-6xl gap-10 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <div className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-400 to-sky-600 font-display text-lg font-bold text-slate-950">
              +
            </span>
            <span className="font-display text-lg font-bold text-white">
              Medi<span className="text-cyan-300">Nova</span>
            </span>
          </div>
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-slate-400">{hospital.tagline}</p>
          <p className="mt-6 font-display text-2xl font-bold text-white">{hospital.phone}</p>
          <p className="text-xs uppercase tracking-wider text-slate-500">Appointments &amp; enquiries</p>
        </div>

        <div>
          <p className="mb-4 text-xs font-bold uppercase tracking-[0.25em] text-slate-500">Visit</p>
          <p className="text-sm leading-relaxed text-slate-400">
            MediNova Health City
            <br />
            200 Feet Radial Road
            <br />
            Chennai 600 089
          </p>
        </div>

        <div>
          <p className="mb-4 text-xs font-bold uppercase tracking-[0.25em] text-slate-500">Quick links</p>
          <div className="grid gap-2 text-sm text-slate-400">
            <a href="#doctors" className="transition-colors hover:text-cyan-300">Find a doctor</a>
            <a href="#packages" className="transition-colors hover:text-cyan-300">Health packages</a>
            <a href="#emergency" className="transition-colors hover:text-cyan-300">Emergency care</a>
            <a href="#stories" className="transition-colors hover:text-cyan-300">Patient stories</a>
          </div>
        </div>
      </div>

      <div className="mx-auto mt-14 flex max-w-6xl flex-col items-center justify-between gap-4 border-t border-white/10 pt-6 md:flex-row">
        <p className="text-xs text-slate-600">© {new Date().getFullYear()} MediNova — a fictional brand created for demonstration.</p>
        <Link
          href="/"
          className="rounded-full border border-white/15 px-5 py-2 font-display text-xs font-bold uppercase tracking-wider text-slate-300 transition-colors hover:border-cyan-400/50 hover:text-cyan-200"
        >
          Designed &amp; built by CRUD Studio →
        </Link>
      </div>
    </footer>
  );
}
